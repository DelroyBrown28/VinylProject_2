$(document).ready(function () {
    $('.modal').modal();
    $('.sidenav').sidenav();
    $('.tooltipped').tooltip({
        'inDuration': 500,
        'transitionMovement': 0,
        
    });

});